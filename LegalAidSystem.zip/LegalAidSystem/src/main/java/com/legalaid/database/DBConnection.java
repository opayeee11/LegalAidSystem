package com.legalaid.database;

import java.sql.*;

public class DBConnection {

    private static final String URL = "jdbc:sqlite:legal_aid.db";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection(URL);
            createTables(conn);
            return conn;
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite Driver পাওয়া যায়নি!");
        }
    }

    private static void createTables(Connection conn) throws SQLException {
        Statement st = conn.createStatement();

        st.execute("CREATE TABLE IF NOT EXISTS constitutional_rights (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "article_number TEXT," +
            "title TEXT," +
            "description TEXT," +
            "category TEXT," +
            "keywords TEXT)");

        st.execute("CREATE TABLE IF NOT EXISTS legal_issues (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "issue_type TEXT," +
            "issue_keyword TEXT," +
            "suggestion TEXT," +
            "relevant_law TEXT," +
            "contact_authority TEXT)");

        st.execute("CREATE TABLE IF NOT EXISTS gov_services (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "service_name TEXT," +
            "required_documents TEXT," +
            "process_steps TEXT," +
            "office_location TEXT," +
            "website TEXT)");

        st.execute("CREATE TABLE IF NOT EXISTS user_queries (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "query_text TEXT," +
            "query_type TEXT," +
            "result_found INTEGER," +
            "searched_at DATETIME DEFAULT CURRENT_TIMESTAMP)");

        st.close();
    }
}