package com.legalaid.ui;

import com.legalaid.dao.GovServiceDAO;
import com.legalaid.model.GovService;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GovServicePanel extends JPanel {
    private JList<String> serviceList;
    private JTextArea detailArea;
    private List<GovService> services;

    public GovServicePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("🏛️ সরকারি সেবা গাইড");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(title, BorderLayout.NORTH);

        services = new GovServiceDAO().getAll();
        String[] names = services.stream()
                .map(GovService::getServiceName).toArray(String[]::new);

        serviceList = new JList<>(names);
        serviceList.setFont(new Font("SansSerif", Font.PLAIN, 14));
        serviceList.setFixedCellHeight(36);
        serviceList.setBackground(new Color(230, 255, 230));

        JScrollPane listScroll = new JScrollPane(serviceList);
        listScroll.setBorder(BorderFactory.createTitledBorder("সেবার তালিকা"));
        listScroll.setPreferredSize(new Dimension(200, 0));

        detailArea = new JTextArea("← বাম দিক থেকে সেবা বেছে নিন।");
        detailArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        detailArea.setEditable(false);
        detailArea.setLineWrap(true);
        detailArea.setWrapStyleWord(true);
        detailArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane detailScroll = new JScrollPane(detailArea);
        detailScroll.setBorder(BorderFactory.createTitledBorder("বিস্তারিত তথ্য"));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, listScroll, detailScroll);
        split.setDividerLocation(200);
        add(split, BorderLayout.CENTER);

        serviceList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int i = serviceList.getSelectedIndex();
                if (i >= 0) showDetail(services.get(i));
            }
        });
    }

    private void showDetail(GovService s) {
        String text =
            "🏛️ সেবা: " + s.getServiceName() + "\n\n" +
            "📎 প্রয়োজনীয় কাগজপত্র:\n" + s.getRequiredDocuments() + "\n\n" +
            "📝 আবেদনের ধাপ:\n" + s.getProcessSteps() + "\n\n" +
            "📍 অফিস: " + s.getOfficeLocation() + "\n\n" +
            "🌐 ওয়েবসাইট: " + s.getWebsite();
        detailArea.setText(text);
        detailArea.setCaretPosition(0);
    }
}