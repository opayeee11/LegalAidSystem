package com.legalaid.ui;

import com.legalaid.dao.QueryHistoryDAO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class HistoryPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private QueryHistoryDAO historyDAO = new QueryHistoryDAO();

    public HistoryPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("🕓 সার্চ ইতিহাস");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        add(title, BorderLayout.NORTH);

        String[] cols = {"সার্চ করা বিষয়", "ধরন", "ফলাফল", "সময়"};
        model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 13));

        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton refresh = new JButton("🔄 রিফ্রেশ");
        JButton clear   = new JButton("🗑️ মুছুন");

        refresh.addActionListener(e -> load());
        clear.addActionListener(e -> {
            int ok = JOptionPane.showConfirmDialog(this,
                "সব ইতিহাস মুছে দিতে চান?", "নিশ্চিত করুন",
                JOptionPane.YES_NO_OPTION);
            if (ok == JOptionPane.YES_OPTION) { historyDAO.clearHistory(); load(); }
        });

        btnPanel.add(refresh); btnPanel.add(clear);
        add(btnPanel, BorderLayout.SOUTH);
        load();
    }

    public void load() {
        model.setRowCount(0);
        for (String[] row : historyDAO.getHistory()) model.addRow(row);
    }
}