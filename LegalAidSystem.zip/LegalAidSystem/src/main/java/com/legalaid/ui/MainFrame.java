package com.legalaid.ui;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private HistoryPanel historyPanel;

    // Global Bangla fonts
    private final Font banglaFont = new Font("Nirmala UI", Font.PLAIN, 14);
    private final Font banglaBold = new Font("Nirmala UI", Font.BOLD, 16);

    public MainFrame() {

        // MUST be first
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            UIManager.put("defaultFont", banglaFont);

            UIManager.put("Label.font", banglaFont);
            UIManager.put("Button.font", banglaFont);
            UIManager.put("TextArea.font", banglaFont);
            UIManager.put("TextField.font", banglaFont);
            UIManager.put("TextPane.font", banglaFont);
            UIManager.put("EditorPane.font", banglaFont);
            UIManager.put("Table.font", banglaFont);
            UIManager.put("TableHeader.font", banglaFont);
            UIManager.put("List.font", banglaFont);
            UIManager.put("TabbedPane.font", banglaFont);
            UIManager.put("OptionPane.messageFont", banglaFont);
            UIManager.put("OptionPane.buttonFont", banglaFont);

        } catch (Exception e) {
            e.printStackTrace();
        }

        setTitle("Aini Sahayak - Bangladesh Legal Aid System");
        setSize(950, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // HEADER
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(0, 58, 114));
        header.setPreferredSize(new Dimension(0, 70));

        JLabel h1 = new JLabel("  Bangladesh Legal Aid System");
        h1.setFont(banglaBold);
        h1.setForeground(Color.WHITE);

        JLabel h2 = new JLabel("  Sambidhanic Adhikar Janun | Aini Poramorso Nin | Sarkari Seba Janun");
        h2.setFont(banglaFont);
        h2.setForeground(new Color(180, 210, 255));

        header.add(h1, BorderLayout.CENTER);
        header.add(h2, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);

        // TABS
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(banglaBold);

        tabs.addTab("Constitutional Rights", new RightsPanel());
        tabs.addTab("Legal Advice", new LegalPanel());
        tabs.addTab("Gov Services", new GovServicePanel());

        historyPanel = new HistoryPanel();
        tabs.addTab("Search History", historyPanel);

        tabs.addChangeListener(e -> {
            if (tabs.getSelectedIndex() == 3) {
                historyPanel.load();
            }
        });

        add(tabs, BorderLayout.CENTER);

        // FOOTER
        JLabel footer = new JLabel(
                "For general information only. Consult a lawyer for important matters. Hotline: 16430",
                SwingConstants.CENTER
        );

        footer.setFont(banglaFont);
        footer.setForeground(Color.DARK_GRAY);

        add(footer, BorderLayout.SOUTH);

        setVisible(true);
    }
}