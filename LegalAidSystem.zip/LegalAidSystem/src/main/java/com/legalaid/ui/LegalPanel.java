package com.legalaid.ui;

import com.legalaid.dao.LegalIssueDAO;
import com.legalaid.dao.QueryHistoryDAO;
import com.legalaid.model.LegalIssue;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class LegalPanel extends JPanel {
    private JTextField searchField;
    private JTextArea resultArea;
    private LegalIssueDAO legalDAO = new LegalIssueDAO();
    private QueryHistoryDAO historyDAO = new QueryHistoryDAO();

    public LegalPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(255, 248, 240));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel info = new JLabel("<html><b>⚖️ আপনার সমস্যা লিখুন</b><br>"
                + "<small>যেমন: জমি দখল, তালাক, পুলিশ হয়রানি, বেতন না দেওয়া</small></html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 14));

        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JButton btn = new JButton("পরামর্শ নিন");
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setBackground(new Color(140, 40, 0));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(130, 36));

        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(new Color(255, 248, 240));
        row.add(searchField, BorderLayout.CENTER);
        row.add(btn, BorderLayout.EAST);

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.setBackground(new Color(255, 248, 240));
        top.add(info, BorderLayout.NORTH);
        top.add(row, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        resultArea = new JTextArea("সমস্যার বিষয় লিখুন এবং 'পরামর্শ নিন' বোতামে ক্লিক করুন।");
        resultArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scroll = new JScrollPane(resultArea);
        scroll.setBorder(BorderFactory.createTitledBorder("💡 আইনি পরামর্শ"));
        add(scroll, BorderLayout.CENTER);

        btn.addActionListener(e -> doSearch());
        searchField.addActionListener(e -> doSearch());
    }

    private void doSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) {
            JOptionPane.showMessageDialog(this, "সমস্যার বিষয় লিখুন।");
            return;
        }
        List<LegalIssue> res = legalDAO.searchByKeyword(q);
        historyDAO.saveQuery(q, "আইনি পরামর্শ", !res.isEmpty());

        if (res.isEmpty()) {
            resultArea.setText("❌ সরাসরি পরামর্শ পাওয়া যায়নি।\n\n"
                    + "💡 আপনি যা করতে পারেন:\n"
                    + "• নিকটস্থ আইনজীবীর সাথে যোগাযোগ করুন\n"
                    + "• জেলা আইনি সহায়তা কমিটিতে যান\n"
                    + "• জাতীয় আইনি সহায়তা হটলাইন: ১৬৪৩০");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (LegalIssue issue : res) {
            sb.append("🔴 সমস্যার ধরন: ").append(issue.getIssueType()).append("\n\n");
            sb.append("✅ করণীয়:\n").append(issue.getSuggestion()).append("\n\n");
            sb.append("📖 প্রযোজ্য আইন: ").append(issue.getRelevantLaw()).append("\n\n");
            sb.append("🏢 কোথায় যাবেন: ").append(issue.getContactAuthority()).append("\n");
            sb.append("═".repeat(50)).append("\n\n");
        }
        resultArea.setText(sb.toString());
        resultArea.setCaretPosition(0);
    }
}