package com.legalaid.ui;

import com.legalaid.dao.QueryHistoryDAO;
import com.legalaid.dao.RightsDAO;
import com.legalaid.model.ConstitutionalRight;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class RightsPanel extends JPanel {
    private JTextField searchField;
    private JTextArea resultArea;
    private RightsDAO rightsDAO = new RightsDAO();
    private QueryHistoryDAO historyDAO = new QueryHistoryDAO();

    public RightsPanel() {
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(240, 248, 255));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel info = new JLabel("<html><b>🔍 সাংবিধানিক অধিকার খুঁজুন</b><br>"
                + "<small>যেমন: গ্রেপ্তার, বাক স্বাধীনতা, সম্পত্তি, বৈষম্য</small></html>");
        info.setFont(new Font("SansSerif", Font.PLAIN, 14));

        searchField = new JTextField();
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JButton searchBtn = makeBtn("খুঁজুন", new Color(0, 85, 164));
        JButton allBtn    = makeBtn("সব দেখুন", new Color(74, 106, 138));

        JPanel btns = new JPanel(new GridLayout(1, 2, 5, 0));
        btns.setBackground(new Color(240, 248, 255));
        btns.add(searchBtn); btns.add(allBtn);

        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(new Color(240, 248, 255));
        row.add(searchField, BorderLayout.CENTER);
        row.add(btns, BorderLayout.EAST);

        JPanel top = new JPanel(new BorderLayout(0, 10));
        top.setBackground(new Color(240, 248, 255));
        top.add(info, BorderLayout.NORTH);
        top.add(row, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);

        resultArea = new JTextArea();
        resultArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JScrollPane scroll = new JScrollPane(resultArea);
        scroll.setBorder(BorderFactory.createTitledBorder("📋 অনুচ্ছেদ ও অধিকার"));
        add(scroll, BorderLayout.CENTER);

        searchBtn.addActionListener(e -> doSearch());
        allBtn.addActionListener(e -> showAll());
        searchField.addActionListener(e -> doSearch());
        showAll();
    }

    private JButton makeBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setBackground(bg); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setPreferredSize(new Dimension(110, 36));
        return b;
    }

    private void doSearch() {
        String q = searchField.getText().trim();
        if (q.isEmpty()) { showAll(); return; }
        List<ConstitutionalRight> res = rightsDAO.searchByKeyword(q);
        historyDAO.saveQuery(q, "সাংবিধানিক অধিকার", !res.isEmpty());
        render(res);
    }

    private void showAll() { render(rightsDAO.getAll()); }

    private void render(List<ConstitutionalRight> list) {
        if (list.isEmpty()) {
            resultArea.setText("❌ কোনো ফলাফল পাওয়া যায়নি।");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("মোট ").append(list.size()).append("টি অনুচ্ছেদ:\n");
        sb.append("═".repeat(50)).append("\n\n");
        for (ConstitutionalRight r : list) {
            sb.append("📌 ").append(r.getArticleNumber()).append("\n");
            sb.append("   শিরোনাম : ").append(r.getTitle()).append("\n");
            sb.append("   বিবরণ   : ").append(r.getDescription()).append("\n");
            sb.append("   বিভাগ   : ").append(r.getCategory()).append("\n");
            sb.append("─".repeat(50)).append("\n\n");
        }
        resultArea.setText(sb.toString());
        resultArea.setCaretPosition(0);
    }
}