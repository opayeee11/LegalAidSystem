package com.legalaid.model;

public class ConstitutionalRight {
    private int id;
    private String articleNumber, title, description, category, keywords;

    public ConstitutionalRight(int id, String articleNumber, String title,
                               String description, String category, String keywords) {
        this.id = id;
        this.articleNumber = articleNumber;
        this.title = title;
        this.description = description;
        this.category = category;
        this.keywords = keywords;
    }

    public String getArticleNumber() { return articleNumber; }
    public String getTitle()         { return title; }
    public String getDescription()   { return description; }
    public String getCategory()      { return category; }
    public String getKeywords()      { return keywords; }
}