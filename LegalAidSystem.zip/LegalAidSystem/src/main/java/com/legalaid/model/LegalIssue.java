package com.legalaid.model;

public class LegalIssue {
    private int id;
    private String issueType, issueKeyword, suggestion, relevantLaw, contactAuthority;

    public LegalIssue(int id, String issueType, String issueKeyword,
                      String suggestion, String relevantLaw, String contactAuthority) {
        this.id = id;
        this.issueType = issueType;
        this.issueKeyword = issueKeyword;
        this.suggestion = suggestion;
        this.relevantLaw = relevantLaw;
        this.contactAuthority = contactAuthority;
    }

    public String getIssueType()        { return issueType; }
    public String getSuggestion()       { return suggestion; }
    public String getRelevantLaw()      { return relevantLaw; }
    public String getContactAuthority() { return contactAuthority; }
}