package com.legalaid.model;

public class GovService {
    private int id;
    private String serviceName, requiredDocuments, processSteps, officeLocation, website;

    public GovService(int id, String serviceName, String requiredDocuments,
                      String processSteps, String officeLocation, String website) {
        this.id = id;
        this.serviceName = serviceName;
        this.requiredDocuments = requiredDocuments;
        this.processSteps = processSteps;
        this.officeLocation = officeLocation;
        this.website = website;
    }

    public String getServiceName()       { return serviceName; }
    public String getRequiredDocuments() { return requiredDocuments; }
    public String getProcessSteps()      { return processSteps; }
    public String getOfficeLocation()    { return officeLocation; }
    public String getWebsite()           { return website; }
}