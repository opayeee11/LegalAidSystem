package com.legalaid;

import com.legalaid.database.DataSeeder;
import com.legalaid.ui.MainFrame;
import javax.swing.*;
import java.awt.*;

public class LegalAidSystem {
    public static void main(String[] args) {

        System.setProperty("file.encoding", "UTF-8");

        try {
            // Windows এ available বাংলা fonts try করবে
            String[] banglaFonts = {"Vrinda", "Shonar Bangla", "Nirmala UI", "Arial Unicode MS"};
            Font selectedFont = null;

            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            String[] availableFonts = ge.getAvailableFontFamilyNames();

            for (String fontName : banglaFonts) {
                for (String available : availableFonts) {
                    if (available.equalsIgnoreCase(fontName)) {
                        selectedFont = new Font(fontName, Font.PLAIN, 14);
                        break;
                    }
                }
                if (selectedFont != null) break;
            }

            if (selectedFont == null) {
                selectedFont = new Font("SansSerif", Font.PLAIN, 14);
            }

            UIManager.put("Label.font", selectedFont);
            UIManager.put("Button.font", selectedFont);
            UIManager.put("TextArea.font", selectedFont);
            UIManager.put("TextField.font", selectedFont);
            UIManager.put("TabbedPane.font", new Font(selectedFont.getName(), Font.BOLD, 14));
            UIManager.put("Table.font", selectedFont);
            UIManager.put("TableHeader.font", new Font(selectedFont.getName(), Font.BOLD, 13));
            UIManager.put("List.font", selectedFont);
            UIManager.put("TitledBorder.font", selectedFont);

            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

        } catch (Exception e) {
            e.printStackTrace();
        }

        DataSeeder.seedIfEmpty();
        SwingUtilities.invokeLater(() -> new MainFrame());
    }
}