package com.legalaid.dao;

import com.legalaid.database.DBConnection;
import com.legalaid.model.LegalIssue;
import java.sql.*;
import java.util.*;

public class LegalIssueDAO {

    public List<LegalIssue> searchByKeyword(String keyword) {
        List<LegalIssue> list = new ArrayList<>();
        String sql = "SELECT * FROM legal_issues WHERE issue_keyword LIKE ? OR issue_type LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String k = "%" + keyword + "%";
            ps.setString(1, k); ps.setString(2, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new LegalIssue(
                    rs.getInt("id"), rs.getString("issue_type"),
                    rs.getString("issue_keyword"), rs.getString("suggestion"),
                    rs.getString("relevant_law"), rs.getString("contact_authority")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}