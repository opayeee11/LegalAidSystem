package com.legalaid.dao;

import com.legalaid.database.DBConnection;
import com.legalaid.model.ConstitutionalRight;
import java.sql.*;
import java.util.*;

public class RightsDAO {

    public List<ConstitutionalRight> searchByKeyword(String keyword) {
        List<ConstitutionalRight> list = new ArrayList<>();
        String sql = "SELECT * FROM constitutional_rights WHERE " +
                     "keywords LIKE ? OR title LIKE ? OR description LIKE ? OR article_number LIKE ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String k = "%" + keyword + "%";
            ps.setString(1, k); ps.setString(2, k);
            ps.setString(3, k); ps.setString(4, k);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ConstitutionalRight(
                    rs.getInt("id"), rs.getString("article_number"),
                    rs.getString("title"), rs.getString("description"),
                    rs.getString("category"), rs.getString("keywords")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public List<ConstitutionalRight> getAll() {
        List<ConstitutionalRight> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM constitutional_rights")) {
            while (rs.next()) {
                list.add(new ConstitutionalRight(
                    rs.getInt("id"), rs.getString("article_number"),
                    rs.getString("title"), rs.getString("description"),
                    rs.getString("category"), rs.getString("keywords")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}