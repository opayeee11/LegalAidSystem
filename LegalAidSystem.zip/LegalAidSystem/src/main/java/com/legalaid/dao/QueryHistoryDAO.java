package com.legalaid.dao;

import com.legalaid.database.DBConnection;
import java.sql.*;
import java.util.*;

public class QueryHistoryDAO {

    public void saveQuery(String queryText, String queryType, boolean resultFound) {
        String sql = "INSERT INTO user_queries (query_text, query_type, result_found) VALUES (?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, queryText);
            ps.setString(2, queryType);
            ps.setInt(3, resultFound ? 1 : 0);
            ps.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public List<String[]> getHistory() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT * FROM user_queries ORDER BY searched_at DESC LIMIT 50";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new String[]{
                    rs.getString("query_text"),
                    rs.getString("query_type"),
                    rs.getInt("result_found") == 1 ? "✅ পাওয়া গেছে" : "❌ পাওয়া যায়নি",
                    rs.getString("searched_at")
                });
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public void clearHistory() {
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement()) {
            st.execute("DELETE FROM user_queries");
        } catch (SQLException e) { e.printStackTrace(); }
    }
}