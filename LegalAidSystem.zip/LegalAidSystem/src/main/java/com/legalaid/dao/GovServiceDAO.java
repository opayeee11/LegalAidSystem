package com.legalaid.dao;

import com.legalaid.database.DBConnection;
import com.legalaid.model.GovService;
import java.sql.*;
import java.util.*;

public class GovServiceDAO {

    public List<GovService> getAll() {
        List<GovService> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM gov_services")) {
            while (rs.next()) {
                list.add(new GovService(
                    rs.getInt("id"), rs.getString("service_name"),
                    rs.getString("required_documents"), rs.getString("process_steps"),
                    rs.getString("office_location"), rs.getString("website")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
}